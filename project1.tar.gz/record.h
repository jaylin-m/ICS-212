/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        September 23, 2023
//
//  FILE:        record.h
//
//  DESCRIPTION:
//   This file contains the data structure of record
//   for Homework 3b - the bank database application
//
****************************************************************/

struct record
{
    int accountno;
    char name[30];
    char address[50];
    struct record* next;
};
