/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 28, 2023
//
//  FILE:        database.c
//
//  DESCRIPTION:
//   This file contains the database functions
//   for Homework 3b - the bank database application
//   It contains the functions: addRecord, printAllRecords, findRecord, and deleteRecord
//
****************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "database.h"

extern int debugmode;

/*****************************************************************
//
//  Function name: addRecord
//
//  DESCRIPTION:   An addRecord function
//                 This function takes the customer's
//                 account number, name, and mailing address.
//                 Then, it adds the customer's record to the
//                 database.
//
//  Parameters:    startAddress (struct record **) : the address of a
//                                             pointer to a customer's
//                                             record in the database
//                 uaccountno (int) : the customer's account number
//                 uname (char []) : the customer's name
//                 uaddress (char []) : the customer's mailing address
//
//  Return values:  0 : success, a record has been added to the database
//                 -1 : fail, a record has not been added to the database
//
****************************************************************/

int addRecord(struct record ** startAddress, int uaccountno, char uname[], char uaddress[])
{
    int stop;
    int result;
    struct record * new;
    struct record * addressOfPrevious;
    struct record * addressOfNext;

    stop = 0;
    result = -1;

    if (debugmode == 1)
    {
        printf("\nDebug Message:\n");
        printf("The addRecord function has been called.\n");
        printf("The function parameter names and values are listed below,\n");
        printf("uaccountno: \n%d\n", uaccountno);
        printf("uname: \n%s\n", uname);
        printf("uaddress: \n%s\n", uaddress);
    }

    if (*startAddress == NULL)
    {
        *startAddress = (struct record *)malloc(sizeof(struct record));
        (*startAddress) -> accountno = uaccountno;
        strcpy((*startAddress) -> name, uname);
        strcpy((*startAddress) -> address, uaddress);
        (*startAddress) -> next = NULL;

        result = 0;
    }
    else if (uaccountno == (*startAddress) -> accountno)
    {
        result = -1;
    }
    else if (uaccountno > (*startAddress) -> accountno)
    {
        new = (struct record *)malloc(sizeof(struct record));
        new -> accountno = uaccountno;
        strcpy(new -> name, uname);
        strcpy(new -> address, uaddress);
        new -> next = *startAddress;
        *startAddress = new;

        result = 0;
    }
    else
    {
        if ((*startAddress) -> next != NULL)
        {
            addressOfPrevious = *startAddress;
            addressOfNext = (*startAddress) -> next;
            while (stop == 0)
            {
                if (uaccountno == addressOfNext -> accountno)
                {
                    stop = 1;
                    result = -1;
                }
                else if (uaccountno < addressOfNext -> accountno)
                {
                    if (addressOfNext -> next == NULL)
                    {
                        new = (struct record *)malloc(sizeof(struct record));
                        new -> accountno = uaccountno;
                        strcpy(new -> name, uname);
                        strcpy(new -> address, uaddress);
                        new -> next = NULL;
                        addressOfNext -> next = new;

                        stop = 1;
                        result = 0;
                    }
                    else
                    {
                        addressOfPrevious = addressOfNext;
                        addressOfNext = addressOfNext -> next;
                    }
                }
                else
                {
                    new = (struct record *)malloc(sizeof(struct record));
                    new -> accountno = uaccountno;
                    strcpy(new -> name, uname);
                    strcpy(new -> address, uaddress);
                    new -> next = addressOfNext;
                    addressOfPrevious -> next = new;

                    stop = 1;
                    result = 0;
                }
            }
        }
        else
        {
            new = (struct record *)malloc(sizeof(struct record));
            new -> accountno = uaccountno;
            strcpy(new -> name, uname);
            strcpy(new -> address, uaddress);
            new -> next = NULL;
            (*startAddress) -> next = new;

            result = 0;
        }
    }

    return result;
}

/*****************************************************************
//
//  Function name: printAllRecords
//
//  DESCRIPTION:   A printAllRecords function
//                 This function prints all records in the
//                 database.
//
//  Parameters:    start (struct record *) : the address of a
//                                           customer's record
//                                           in the database
//
//  Return values:  There are no return values.
//
****************************************************************/

void printAllRecords(struct record * start)
{
    if (debugmode == 1)
    {
        printf("\nDebug Message:\n");
        printf("The printAllRecords function has been called.\n");
    }

    if (start != NULL)
    {
        while (start != NULL)
        {
            printf("\nAccount Number:\n%d", start -> accountno);
            printf("\nName:\n%s", start -> name);
            printf("\nMailing Address:\n%s\n", start -> address);
            start = start -> next;
        }

        printf("\nAll records in the database have been printed.\n");
    }
    else
    {
        printf("\nThere are no customer records in the database.\n");
    }
}

/*****************************************************************
//
//  Function name: findRecord
//
//  DESCRIPTION:   A findRecord function
//                 This function takes the customer's account
//                 number.
//                 Then, it finds the customer's record(s)
//                 with the specified account number.
//
//  Parameters:    start (struct record *) : the address of a
//                                           customer's record
//                                           in the database
//                 uaccountno (int) : the customer's account number
//
//  Return values:  0 : success, a record has been found in the database
//                 -1 : fail, a record has not been found in the database
//
****************************************************************/

int findRecord(struct record * start, int uaccountno)
{
    int stop;
    int result;

    stop = 0;
    result = -1;

    if (debugmode == 1)
    {
        printf("\nDebug Message:\n");
        printf("The findRecord function has been called.\n");
        printf("The function parameter names and values are listed below,\n");
        printf("uaccountno: \n%d\n", uaccountno);
    }

    if (start != NULL)
    {
        while (stop == 0)
        {
            if (start == NULL)
            {
                stop = 1;
            }
            else if (uaccountno == start -> accountno)
            {
                printf("\nAccount Number:\n%d", start -> accountno);
                printf("\nName:\n%s", start -> name);
                printf("\nMailing Address:\n%s\n", start -> address);

                stop = 1;
                result = 0;
            }
            else
            {
                start = start -> next;
            }
        }
    }

    return result;
}

/*****************************************************************
//
//  Function name: deleteRecord
//
//  DESCRIPTION:   A deleteRecord function
//                 This function takes the customer's account
//                 number.
//                 Then, it deletes the customer's existing record(s)
//                 from the database using the account number as a key.
//
//  Parameters:    startAddress (struct record **) : the address of a
//                                                pointer to a customer's
//                                                record in the database
//                 uaccountno (int) : the customer's account number
//
//  Return values:  0 : success, a record has been deleted from the database
//                 -1 : fail, a record has not been deleted from the database
//
****************************************************************/

int deleteRecord(struct record ** startAddress, int uaccountno)
{
    int stop;
    int result;
    struct record * temp;
    struct record * addressOfCurrent;
    struct record * addressOfNext;

    stop = 0;
    result = -1;

    if (debugmode == 1)
    {
        printf("\nDebug Message:\n");
        printf("The deleteRecord function has been called.\n");
        printf("The function parameter names and values are listed below,\n");
        printf("uaccountno: \n%d\n", uaccountno);
    }

    if (*startAddress != NULL)
    {
        if (uaccountno == (*startAddress) -> accountno)
        {
            if ((*startAddress) -> next == NULL)
            {
                free(*startAddress);
                *startAddress = NULL;

                result = 0;
            }
            else
            {
                temp = (*startAddress) -> next;
                free(*startAddress);
                *startAddress = temp;

                result = 0;
            }
        }
        else
        {
            addressOfCurrent = *startAddress;
            addressOfNext = (*startAddress) -> next;
            while (stop == 0)
            {
                if (addressOfNext != NULL && uaccountno == addressOfNext -> accountno)
                {
                    if (addressOfNext -> next != NULL)
                    {
                        temp = addressOfNext -> next;
                        free(addressOfNext);
                        addressOfCurrent -> next = temp;

                        stop = 1;
                        result = 0;
                    }
                    else
                    {
                        free(addressOfNext);
                        addressOfCurrent -> next = NULL;

                        stop = 1;
                        result = 0;
                    }
                }
                else
                {
                    if (addressOfNext == NULL)
                    {
                        stop = 1;
                    }
                    else if (addressOfNext -> next == NULL)
                    {
                        stop = 1;
                    }
                    else
                    {
                        addressOfCurrent = addressOfNext;
                        addressOfNext = addressOfNext -> next;
                    }
                }
            }
        }
    }
    return result;
}

/*****************************************************************
//
//  Function name: writefile
//
//  DESCRIPTION:   A writefile function
//                 This function will write the data stored in
//                 the database into a text file.
//
//  Parameters:    start (struct record *) : the address of a
//                                           customer's record
//                                           in the database
//                 filename (char[]) : the name of the file
//                                     to be written
//
//  Return values:  0 : success, successfully opened file
//                 -1 : fail, unsuccessfully opened file
//
****************************************************************/

int writefile(struct record * start, char filename[])
{
    FILE * infile;
    int successfulOpenFile;

    infile = fopen(filename, "w");
    successfulOpenFile = -1;

    if (debugmode == 1)
    {
        printf("\nDebug Message:\n");
        printf("The writefile function has been called.\n");
        printf("The function parameter names and values are listed below,\n");
        printf("filename: \n%s\n", filename);
    }

    if (infile != NULL)
    {
        successfulOpenFile = 0;

        while (start != NULL)
        {
            fprintf(infile, "%d?\n", start -> accountno);
            fprintf(infile, "%s?\n", start -> name);
            fprintf(infile, "%s?\n", start -> address);
            start = start -> next;
        }

        fclose(infile);
    }

    return successfulOpenFile;
}

/*****************************************************************
//
//  Function name: readfile
//
//  DESCRIPTION:   A readfile function
//                 This function will read the data from a text
//                 file and store it in the database.
//
//  Parameters:    startAddress (struct record **) : the address of
//                                        a pointer to a customer's
//                                        record in the database
//                 filename (char[]) : the name of the file
//                                     to be read
//
//  Return values:  0 : success, successfully opened file
//                 -1 : fail, unsuccessfully opened file
//
****************************************************************/

int readfile(struct record ** startAddress, char filename[])
{
    FILE * infile;
    int successfulOpenFile;
    int raccountno;
    char rname[30];
    char raddress[50];
    struct record * addressOfCurrent;
    struct record * addressOfPrevious;

    int isFirstRecord;
    int currentPosition;
    char currentCharacter;

    infile = fopen(filename, "r");
    successfulOpenFile = -1;

    isFirstRecord = 1;

    if (debugmode == 1)
    {
        printf("\nDebug Message:\n");
        printf("The readfile function has been called.\n");
        printf("The function parameter names and values are listed below,\n");
        printf("filename: \n%s\n", filename);
    }

    if (infile != NULL)
    {
        successfulOpenFile = 0;

        while (fscanf(infile, "%d", &raccountno) != EOF)
        {
            if (isFirstRecord == 1)
            {
                *startAddress = (struct record *)malloc(sizeof(struct record));
                currentCharacter = fgetc(infile);

                if (currentCharacter == '?')
                {
                    currentCharacter = fgetc(infile);
                    currentCharacter = fgetc(infile);
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        rname[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = fgetc(infile);
                    }
                }

                if (currentCharacter == '?')
                {
                    currentCharacter = fgetc(infile);
                    currentCharacter = fgetc(infile);
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        raddress[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = fgetc(infile);
                    }
                    currentCharacter = fgetc(infile);
                }

                (*startAddress) -> accountno = raccountno;
                strcpy((*startAddress) -> name, rname);
                strcpy((*startAddress) -> address, raddress);
                (*startAddress) -> next = NULL;

                isFirstRecord = 0;

                addressOfPrevious = *startAddress;
            }
            else
            {
                addressOfCurrent = (struct record *)malloc(sizeof(struct record));
                addressOfPrevious -> next = addressOfCurrent;
                currentCharacter = fgetc(infile);

                if (currentCharacter == '?')
                {
                    currentPosition = 0;
                    while (currentPosition < 29)
                    {
                        rname[currentPosition] = '\0';
                        currentPosition++;
                    }

                    currentCharacter = fgetc(infile);
                    currentCharacter = fgetc(infile);
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        rname[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = fgetc(infile);
                    }
                }

                if (currentCharacter == '?')
                {
                    currentPosition = 0;
                    while (currentPosition < 49)
                    {
                        raddress[currentPosition] = '\0';
                        currentPosition++;
                    }

                    currentCharacter = fgetc(infile);
                    currentCharacter = fgetc(infile);
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        raddress[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = fgetc(infile);
                    }
                    currentCharacter = fgetc(infile);
                }

                addressOfCurrent -> accountno = raccountno;
                strcpy(addressOfCurrent -> name, rname);
                strcpy(addressOfCurrent -> address, raddress);
                addressOfCurrent -> next = NULL;

                addressOfPrevious = addressOfCurrent;
            }
        }
    }

    return successfulOpenFile;
}

/*****************************************************************
//
//  Function name: cleanup
//
//  DESCRIPTION:   A cleanup function
//                 This function will deallocate all the
//                 allocated spaces in the heap memory and
//                 assign NULL to start. It will clean up the
//                 heap memory by releasing all the allocated
//                 spaces in the heap memory, then assign NULL
//                 to start.
//
//  Parameters:    startAddress (struct record **) : the address of
//                                        a pointer to a customer's
//                                        record in the database
//
//  Return values:  There are no return values.
//
****************************************************************/

void cleanup(struct record ** startAddress)
{
    struct record * freeRecord;

    if (debugmode == 1)
    {
        printf("\nDebug Message:\n");
        printf("The cleanup function has been called.\n");
    }

    while ((*startAddress) != NULL)
    {
        freeRecord = *startAddress;
        *startAddress = (*startAddress) -> next;
        free(freeRecord);
    }

    *startAddress = NULL;
}
