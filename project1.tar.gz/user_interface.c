/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 28, 2023
//
//  FILE:        user_interface.c
//
//  DESCRIPTION:
//   This file contains the user_interface functions
//   It contains the main function and the getaddress function
//   for Homework 3b - the bank database application
//
****************************************************************/

#include <stdio.h>
#include <string.h>
#include "database.h"

void getaddress(char[], int);

int debugmode;

/*****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   A main function
//                 This function checks if the user entered only
//                 the executable name, the executable name
//                 with the debug option, or if they entered
//                 invalid command-line arguments.
//                 If the user enters invalid command-line
//                 arguments, the program will give an error
//                 message and exit.
//                 If the user enters valid command-line
//                 arguments, the program will proceed to run
//                 with or without the debug option as
//                 specified by the user.
//                 It prints an introductory message of the
//                 program, the instruction for the user to
//                 choose a menu option, and the menu options.
//                 It obtains the input of the user's chosen
//                 menu option. If the user enters the
//                 partial or full name of a valid menu
//                 option, it will call the corresponding
//                 function (among addRecord, printAllRecords,
//                 findRecord, or deleteRecord) or quit the
//                 program if the user chooses to quit. If the
//                 user enters an invalid menu option it will
//                 display an error message and ask for a valid
//                 menu option.
//                 If the user enters a valid menu option name,
//                 it will ask for additional information if
//                 necessary.
//                 Then, it will print a completion message
//                 and display the menu and ask for a menu
//                 option again unless the selected option was
//                 to quit the program.
//
//  Parameters:    argc (int) : the number of elements in argv
//                 argv (char*[]) : an array of arguments passed
//                                  to the program
//
//  Return values:  0 : success
//
****************************************************************/

int main(int argc, char* argv[])
{
    struct record * start = NULL;
    int isInvalidArguments;
    int stopProgram;
    int isAccountNumberValid;
    int accountNumber;
    int count;
    char menuOption[10];
    char temp[300];
    char name[30];
    char address[50];

    isInvalidArguments = 0;
    stopProgram = 0;

    if (argc == 1)
    {
        debugmode = 0;
    }
    else if (argc == 2 && strcmp(argv[1], "debug") == 0)
    {
        debugmode = 1;
    }
    else
    {
        printf("Error: You have entered Invalid Command-Line Arguments\n");
        isInvalidArguments = 1;
    }

    if (isInvalidArguments == 0)
    {
        if (readfile(&start, "database.txt") == 0)
        {
            printf("\nThe file 'database.txt' has been successfully read.\n");
        }
        else
        {
            printf("\nThe file 'database.txt' has not been successfully read.\n");
        }

        printf("\nWelcome! This program is a Bank Database Application.\n");
        printf("This Bank Database Application allows you to ");
        printf("manage customers' bank records stored in the database.\n");
        printf("You may create a new record, view existing records, ");
        printf("search for a record, or delete a record.\n\n");

        printf("To choose a menu option, please type the partial or full name ");
        printf("of the menu option. Then press the 'enter' button on your keyboard.");

        while (stopProgram == 0)
        {
            printf("\nThe menu options are listed below,\n");
            printf("add: The 'add' menu option will add a new record in the database\n");
            printf("printall: The 'printall' menu option will print all records in the database\n");
            printf("find: The 'find' menu option will find record(s) with ");
            printf("a specified account number\n");
            printf("delete: The 'delete' menu option will delete existing record(s) ");
            printf("from the database using the account number as a key\n");
            printf("quit: The 'quit' menu option will quit the program\n\n");

            printf("Please enter a menu option.\n");

            scanf("%s", menuOption);
            fgets(temp, 300, stdin);
            if (strcmp(menuOption, "a") == 0 || strcmp(menuOption, "ad") == 0)
            {
                printf("\nThe 'add' menu option has been chosen.\n");
                printf("\nPlease enter the customer's account number.\n");

                isAccountNumberValid = 0;

                while (isAccountNumberValid == 0)
                {
                    if (scanf("%d", &accountNumber) == 1)
                    {
                        if (accountNumber > 0)
                        {
                            isAccountNumberValid = 1;
                        }
                        else
                        {
                            printf("\nError: You have entered a number ");
                            printf("less than or equal to 0.\n\n");
                            printf("Please enter a positive integer.\n");
                        }
                        fgets(temp, 300, stdin);
                    }
                    else
                    {
                        fgets(temp, 300, stdin);
                        printf("\nError: You have entered a character or a string.\n\n");
                        printf("Please enter a positive integer.\n");
                    }
                }

                printf("\nPlease enter the customer's name.\n");
                fgets(name, 30, stdin);
                if (name[28] == '\0')
                {
                    name[29] = '\n';
                }
                if (name[29] != '\n')
                {
                    fgets(temp, 300, stdin);
                    name[29] = '\n';
                }

                printf("\nPlease enter the customer's address.\n");
                printf("After you have finished typing the customer's address, ");
                printf("type '?' and press the 'enter' button.\n");
                getaddress(address, 50);

                count = 0;
                while (count < 30 && name[count] != '\n')
                {
                    count++;
                }

                if (name[count] == '\n')
                {
                    name[count] = '\0';
                }

                if (addRecord(&start, accountNumber, name, address) == 0)
                {
                    printf("\nYou have added a customer's record.\n");
                }
                else
                {
                    printf("\nError: Attempted to add a duplicate customer record.\n");
                    printf("\nA record has not been added.\n");
                }
            }
            else if (strcmp(menuOption, "add") == 0)
            {
                printf("\nThe 'add' menu option has been chosen.\n");
                printf("\nPlease enter the customer's account number.\n");

                isAccountNumberValid = 0;

                while (isAccountNumberValid == 0)
                {
                    if (scanf("%d", &accountNumber) == 1)
                    {
                        if (accountNumber > 0)
                        {
                            isAccountNumberValid = 1;
                        }
                        else
                        {
                            printf("\nError: You have entered a number ");
                            printf("less than or equal to 0.\n\n");
                            printf("Please enter a positive integer.\n");
                        }
                        fgets(temp, 300, stdin);
                    }
                    else
                    {
                        fgets(temp, 300, stdin);
                        printf("\nError: You have entered a character or a string.\n\n");
                        printf("Please enter a positive integer.\n");
                    }
                }

                printf("\nPlease enter the customer's name.\n");
                fgets(name, 30, stdin);
                if (name[28] == '\0')
                {
                    name[29] = '\n';
                }
                if (name[29] != '\n')
                {
                    fgets(temp, 300, stdin);
                    name[29] = '\n';
                }

                printf("\nPlease enter the customer's address.\n");
                printf("After you have finished typing the customer's address, ");
                printf("type '?' and press the 'enter' button.\n");
                getaddress(address, 50);

                count = 0;
                while (count < 30 && name[count] != '\n')
                {
                    count++;
                }

                if (name[count] == '\n')
                {
                    name[count] = '\0';
                }

                if (addRecord(&start, accountNumber, name, address) == 0)
                {
                    printf("\nYou have added a customer's record.\n");
                }
                else
                {
                    printf("\nError: Attempted to add a duplicate customer record.\n");
                    printf("\nA record has not been added.\n");
                }
            }
            else if (strcmp(menuOption, "p") == 0 || strcmp(menuOption, "pr") == 0)
            {
                printf("\nThe 'printall' menu option has been chosen.\n");
                printAllRecords(start);
            }
            else if (strcmp(menuOption, "pri") == 0 || strcmp(menuOption, "prin") == 0)
            {
                printf("\nThe 'printall' menu option has been chosen.\n");
                printAllRecords(start);
            }
            else if (strcmp(menuOption, "print") == 0 || strcmp(menuOption, "printa") == 0)
            {
                printf("\nThe 'printall' menu option has been chosen.\n");
                printAllRecords(start);
            }
            else if (strcmp(menuOption, "printal") == 0 || strcmp(menuOption, "printall") == 0)
            {
                printf("\nThe 'printall' menu option has been chosen.\n");
                printAllRecords(start);
            }
            else if (strcmp(menuOption, "f") == 0 || strcmp(menuOption, "fi") == 0)
            {
                printf("\nThe 'find' menu option has been chosen.\n");
                printf("\nPlease enter the customer's account number.\n");

                isAccountNumberValid = 0;
                while (isAccountNumberValid == 0)
                {
                    if (scanf("%d", &accountNumber) == 1)
                    {
                        if (accountNumber > 0)
                        {
                            isAccountNumberValid = 1;
                        }
                        else
                        {
                            printf("\nError: You have entered a number ");
                            printf("less than or equal to 0.\n\n");
                            printf("Please enter a positive integer.\n");
                        }
                    }
                    else
                    {
                        fgets(temp, 300, stdin);
                        printf("\nError: You have entered a character or a string.\n\n");
                        printf("Please enter a positive integer.\n");
                    }
                }

                if (findRecord(start, accountNumber) == 0)
                {
                    printf("\nYou have found a customer's record.\n");
                }
                else
                {
                    printf("\nA record has not been found.\n");
                }
            }
            else if (strcmp(menuOption, "fin") == 0 || strcmp(menuOption, "find") == 0)
            {
                printf("\nThe 'find' menu option has been chosen.\n");
                printf("\nPlease enter the customer's account number.\n");

                isAccountNumberValid = 0;
                while (isAccountNumberValid == 0)
                {
                    if (scanf("%d", &accountNumber) == 1)
                    {
                        if (accountNumber > 0)
                        {
                            isAccountNumberValid = 1;
                        }
                        else
                        {
                            printf("\nError: You have entered a number ");
                            printf("less than or equal to 0.\n\n");
                            printf("Please enter a positive integer.\n");
                        }
                    }
                    else
                    {
                        fgets(temp, 300, stdin);
                        printf("\nError: You have entered a character or a string.\n\n");
                        printf("Please enter a positive integer.\n");
                    }
                }

                if (findRecord(start, accountNumber) == 0)
                {
                    printf("\nYou have found a customer's record.\n");
                }
                else
                {
                    printf("\nA record has not been found.\n");
                }
            }
            else if (strcmp(menuOption, "d") == 0 || strcmp(menuOption, "de") == 0)
            {
                printf("\nThe 'delete' menu option has been chosen.\n");
                printf("\nPlease enter the customer's account number.\n");

                isAccountNumberValid = 0;
                while (isAccountNumberValid == 0)
                {
                    if (scanf("%d", &accountNumber) == 1)
                    {
                        if (accountNumber > 0)
                        {
                            isAccountNumberValid = 1;
                        }
                        else
                        {
                            printf("\nError: You have entered a number ");
                            printf("less than or equal to 0.\n\n");
                            printf("Please enter a positive integer.\n");
                        }
                    }
                    else
                    {
                        fgets(temp, 300, stdin);
                        printf("\nError: You have entered a character or a string.\n\n");
                        printf("Please enter a positive integer.\n");
                    }
                }

                if (deleteRecord(&start, accountNumber) == 0)
                {
                    printf("\nYou have deleted a customer's record.\n");
                }
                else
                {
                    printf("\nA record has not been deleted.\n");
                }
            }
            else if (strcmp(menuOption, "del") == 0 || strcmp(menuOption, "dele") == 0)
            {
                printf("\nThe 'delete' menu option has been chosen.\n");
                printf("\nPlease enter the customer's account number.\n");

                isAccountNumberValid = 0;
                while (isAccountNumberValid == 0)
                {
                    if (scanf("%d", &accountNumber) == 1)
                    {
                        if (accountNumber > 0)
                        {
                            isAccountNumberValid = 1;
                        }
                        else
                        {
                            printf("\nError: You have entered a number ");
                            printf("less than or equal to 0.\n\n");
                            printf("Please enter a positive integer.\n");
                        }
                    }
                    else
                    {
                        fgets(temp, 300, stdin);
                        printf("\nError: You have entered a character or a string.\n\n");
                        printf("Please enter a positive integer.\n");
                    }
                }

                if (deleteRecord(&start, accountNumber) == 0)
                {
                    printf("\nYou have deleted a customer's record.\n");
                }
                else
                {
                    printf("\nA record has not been deleted.\n");
                }
            }
            else if (strcmp(menuOption, "delet") == 0 || strcmp(menuOption, "delete") == 0)
            {
                printf("\nThe 'delete' menu option has been chosen.\n");
                printf("\nPlease enter the customer's account number.\n");

                isAccountNumberValid = 0;
                while (isAccountNumberValid == 0)
                {
                    if (scanf("%d", &accountNumber) == 1)
                    {
                        if (accountNumber > 0)
                        {
                            isAccountNumberValid = 1;
                        }
                        else
                        {
                            printf("\nError: You have entered a number ");
                            printf("less than or equal to 0.\n\n");
                            printf("Please enter a positive integer.\n");
                        }
                    }
                    else
                    {
                        fgets(temp, 300, stdin);
                        printf("\nError: You have entered a character or a string.\n\n");
                        printf("Please enter a positive integer.\n");
                    }
                }

                if (deleteRecord(&start, accountNumber) == 0)
                {
                    printf("\nYou have deleted a customer's record.\n");
                }
                else
                {
                    printf("\nA record has not been deleted.\n");
                }
            }
            else if (strcmp(menuOption, "q") == 0 || strcmp(menuOption, "qu") == 0)
            {
                printf("\nThe 'quit' menu option has been chosen.\n");
                if (writefile(start, "database.txt") == 0)
                {
                    printf("\nThe file 'database.txt' has been successfully written.\n");
                }
                else
                {
                    printf("\nThe file 'database.txt' has not been successfully written.\n");
                }

                cleanup(&start);

                printf("\nYou have quit the program.\n");
                stopProgram = 1;
            }
            else if (strcmp(menuOption, "qui") == 0 || strcmp(menuOption, "quit") == 0)
            {
                printf("\nThe 'quit' menu option has been chosen.\n");
                if (writefile(start, "database.txt") == 0)
                {
                    printf("\nThe file 'database.txt' has been successfully written.\n");
                }
                else
                {
                    printf("\nThe file 'database.txt' has not been successfully written.\n");
                }

                cleanup(&start);

                printf("\nYou have quit the program.\n");
                stopProgram = 1;
            }
            else
            {
                printf("\nError: You have entered an invalid menu option name.\n\n");
                printf("Please enter a valid menu option.\n\n");
            }
        }
    }

    return 0;
}

/*****************************************************************
//
//  Function name: getaddress
//
//  DESCRIPTION:   A getaddress function
//                 This function obtains the customer's
//                 address information.
//
//  Parameters:    addressArray (char []) : the array of the
//                                          customer's address
//                 addressSize (int) : the size of the addressArray
//
//  Return values:  There are no return values.
//
****************************************************************/

void getaddress(char addressArray[], int addressSize)
{
    int current;
    char nextCharacter;

    current = 0;

    while (current < addressSize - 1)
    {
        if (addressArray[current] != '\0')
        {
            addressArray[current] = '\0';
        }

        nextCharacter = fgetc(stdin);

        if (nextCharacter == '?')
        {
            current = addressSize;
        }
        else
        {
            addressArray[current] = nextCharacter;
            current++;
        }
    }

    addressArray[current] = '\0';
}
