/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        September 23, 2023
//
//  FILE:        database.h
//
//  DESCRIPTION:
//   This file contains the function prototypes for the
//   database functions
//   for Homework 3b - the bank database application
//
****************************************************************/

#include "record.h"

int addRecord(struct record **, int, char [], char []);
void printAllRecords(struct record *);
int findRecord(struct record *, int);
int deleteRecord(struct record **, int);
int writefile(struct record *, char []);
int readfile(struct record **, char []);
void cleanup(struct record **);
