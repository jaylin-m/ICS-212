/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 17, 2023
//
//  FILE:        llist.h
//
//  DESCRIPTION:
//   This file contains the class definition of llist
//   for Project 2 - the bank database application in C++
//
****************************************************************/

#ifndef LLIST_H
#define LLIST_H

#include "record.h"

class llist
{
    private:
    record * start;
    char filename[20];
    int readfile();
    int writefile();
    void cleanup();

    public:
    llist();
    llist(char[]);
    llist(llist &);
    ~llist();
    llist& operator=(const llist&);
    friend ostream& operator<<(ostream&, const llist&);
    int addRecord(int, char[], char[]);
    int findRecord(int);
    void printAllRecords();
    int deleteRecord(int);
};

#endif
