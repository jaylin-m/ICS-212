/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 22, 2023
//
//  FILE:        user_interface.cpp
//
//  DESCRIPTION:
//   This file contains the user_interface functions
//   It contains the main function and the getaddress function
//   for Project 2 - the bank database application in C++
//
****************************************************************/

#include <cstring>
#include <iostream>
using namespace std;
#include "llist.h"

void getaddress(char[], int);

/*****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   A main function
//                 This function checks if the user entered only
//                 the executable name, the executable name
//                 with the debug option, or if they entered
//                 invalid command-line arguments.
//                 If the user enters invalid command-line
//                 arguments, the program will give an error
//                 message and exit.
//                 If the user enters valid command-line
//                 arguments, the program will proceed to run
//                 with or without the debug option as
//                 specified by the user.
//                 It prints an introductory message of the
//                 program, the instruction for the user to
//                 choose a menu option, and the menu options.
//                 It obtains the input of the user's chosen
//                 menu option. If the user enters the
//                 partial or full name of a valid menu
//                 option, it will call the corresponding
//                 function (among addRecord, printAllRecords,
//                 findRecord, or deleteRecord) or quit the
//                 program if the user chooses to quit. If the
//                 user enters an invalid menu option it will
//                 display an error message and ask for a valid
//                 menu option.
//                 If the user enters a valid menu option name,
//                 it will ask for additional information if
//                 necessary.
//                 Then, it will print a completion message
//                 and display the menu and ask for a menu
//                 option again unless the selected option was
//                 to quit the program.
//
//  Parameters:    argc (int) : the number of elements in argv
//                 argv (char*[]) : an array of arguments passed
//                                  to the program
//
//  Return values:  0 : success
//
****************************************************************/

int main(int argc, char* argv[])
{
    int stopProgram;
    int isAccountNumberValid;
    int accountNumber;
    int count;
    char menuOption[20];
    char temp[300];
    char name[30];
    char address[50];

    stopProgram = 0;

    llist* mylist = new llist();

    std::cout << "\nWelcome! This program is a Bank Database Application.\n";
    std::cout << "This Bank Database Application allows you to ";
    std::cout << "manage customers' bank records stored in the database.\n";
    std::cout << "You may create a new record, view existing records, ";
    std::cout << "search for a record, or delete a record.\n\n";

    std::cout << "To choose a menu option, please type the partial or full name ";
    std::cout << "of the menu option. Then press the 'enter' button on your keyboard.";

    while (stopProgram == 0)
    {
        std::cout << "\nThe menu options are listed below,\n";
        std::cout << "add: The 'add' menu option will add a new record in the database\n";
        std::cout << "printall: The 'printall' menu option will print all records ";
        std::cout << "in the database\n";
        std::cout << "find: The 'find' menu option will find record(s) with ";
        std::cout << "a specified account number\n";
        std::cout << "delete: The 'delete' menu option will delete existing record(s) ";
        std::cout << "from the database using the account number as a key\n";
        std::cout << "quit: The 'quit' menu option will quit the program\n\n";

        std::cout << "Please enter a menu option.\n";

        std::cin.getline(menuOption, 20);

        if (strcmp(menuOption, "a") == 0 || strcmp(menuOption, "ad") == 0)
        {
            std::cout << "\nThe 'add' menu option has been chosen.\n";
            std::cout << "\nPlease enter the customer's account number.\n";

            isAccountNumberValid = 0;

            while (isAccountNumberValid == 0)
            {
                if (std::cin >> accountNumber)
                {
                    if (accountNumber > 0)
                    {
                        isAccountNumberValid = 1;
                    }
                    else
                    {
                        std::cout << "\nError: You have entered a number ";
                        std::cout << "less than or equal to 0.\n\n";
                        std::cout << "Please enter a positive integer.\n";
                    }

                    std::cin.getline(temp, 300);
                }
                else
                {
                    std::cin.clear();
                    std::cin >> temp;
                    std::cout << "\nError: You have entered a character or a string.\n\n";
                    std::cout << "Please enter a positive integer.\n";
                }
            }

            std::cout << "\nPlease enter the customer's name.\n";
            std::cin.getline(name, 30);

            if (name[28] == '\0')
            {
                name[29] = '\n';
            }
            if (name[29] != '\n')
            {
                std::cin.getline(temp, 300);
                name[29] = '\n';
            }

            std::cout << "\nPlease enter the customer's address.\n";
            std::cout << "After you have finished typing the customer's address, ";
            std::cout << "type '?' and press the 'enter' button.\n";
            getaddress(address, 50);

            count = 0;
            while (count < 30 && name[count] != '\n')
            {
                count++;
            }

            if (name[count] == '\n')
            {
                name[count] = '\0';
            }

            if (mylist -> addRecord(accountNumber, name, address) == 0)
            {
                std::cout << "\nYou have added a customer's record.\n";
            }
            else
            {
                std::cout << "\nError: Attempted to add a duplicate customer record.\n";
                std::cout << "\nA record has not been added.\n";
            }

            std::cin.getline(temp, 300);
        }
        else if (strcmp(menuOption, "add") == 0)
        {
            std::cout << "\nThe 'add' menu option has been chosen.\n";
            std::cout << "\nPlease enter the customer's account number.\n";

            isAccountNumberValid = 0;

            while (isAccountNumberValid == 0)
            {
                if (std::cin >> accountNumber)
                {
                    if (accountNumber > 0)
                    {
                        isAccountNumberValid = 1;
                    }
                    else
                    {
                        std::cout << "\nError: You have entered a number ";
                        std::cout << "less than or equal to 0.\n\n";
                        std::cout << "Please enter a positive integer.\n";
                    }

                    std::cin.getline(temp, 300);
                }
                else
                {
                    std::cin.clear();
                    std::cin >> temp;
                    std::cout << "\nError: You have entered a character or a string.\n\n";
                    std::cout << "Please enter a positive integer.\n";
                }
            }

            std::cout << "\nPlease enter the customer's name.\n";
            std::cin.getline(name, 30);
            if (name[28] == '\0')
            {
                name[29] = '\n';
            }
            if (name[29] != '\n')
            {
                std::cin.getline(temp, 300);
                name[29] = '\n';
            }

            std::cout << "\nPlease enter the customer's address.\n";
            std::cout << "After you have finished typing the customer's address, ";
            std::cout << "type '?' and press the 'enter' button.\n";
            getaddress(address, 50);

            count = 0;
            while (count < 30 && name[count] != '\n')
            {
                count++;
            }

            if (name[count] == '\n')
            {
                name[count] = '\0';
            }

            if (mylist -> addRecord(accountNumber, name, address) == 0)
            {
                std::cout << "\nYou have added a customer's record.\n";
            }
            else
            {
                std::cout << "\nError: Attempted to add a duplicate customer record.\n";
                std::cout << "\nA record has not been added.\n";
            }

            std::cin.getline(temp, 300);
        }
        else if (strcmp(menuOption, "p") == 0 || strcmp(menuOption, "pr") == 0)
        {
            std::cout << "\nThe 'printall' menu option has been chosen.\n";
            mylist -> printAllRecords();
        }
        else if (strcmp(menuOption, "pri") == 0 || strcmp(menuOption, "prin") == 0)
        {
            std::cout << "\nThe 'printall' menu option has been chosen.\n";
            mylist -> printAllRecords();
        }
        else if (strcmp(menuOption, "print") == 0 || strcmp(menuOption, "printa") == 0)
        {
            std::cout << "\nThe 'printall' menu option has been chosen.\n";
            mylist -> printAllRecords();
        }
        else if (strcmp(menuOption, "printal") == 0 || strcmp(menuOption, "printall") == 0)
        {
            std::cout << "\nThe 'printall' menu option has been chosen.\n";
            mylist -> printAllRecords();
        }
        else if (strcmp(menuOption, "f") == 0 || strcmp(menuOption, "fi") == 0)
        {
            std::cout << "\nThe 'find' menu option has been chosen.\n";
            std::cout << "\nPlease enter the customer's account number.\n";

            isAccountNumberValid = 0;
            while (isAccountNumberValid == 0)
            {
                if (std::cin >> accountNumber)
                {
                    if (accountNumber > 0)
                    {
                        isAccountNumberValid = 1;
                    }
                    else
                    {
                        std::cout << "\nError: You have entered a number ";
                        std::cout << "less than or equal to 0.\n\n";
                        std::cout << "Please enter a positive integer.\n";
                    }
                }
                else
                {
                    std::cin.clear();
                    std::cin >> temp;
                    std::cout << "\nError: You have entered a character or a string.\n\n";
                    std::cout << "Please enter a positive integer.\n";
                }
            }

            if (mylist -> findRecord(accountNumber) == 0)
            {
                std::cout << "\nYou have found a customer's record.\n";
            }
            else
            {
                std::cout << "\nA record has not been found.\n";
            }

            std::cin.getline(temp, 300);
        }
        else if (strcmp(menuOption, "fin") == 0 || strcmp(menuOption, "find") == 0)
        {
            std::cout << "\nThe 'find' menu option has been chosen.\n";
            std::cout << "\nPlease enter the customer's account number.\n";

            isAccountNumberValid = 0;
            while (isAccountNumberValid == 0)
            {
                if (std::cin >> accountNumber)
                {
                    if (accountNumber > 0)
                    {
                        isAccountNumberValid = 1;
                    }
                    else
                    {
                        std::cout << "\nError: You have entered a number ";
                        std::cout << "less than or equal to 0.\n\n";
                        std::cout << "Please enter a positive integer.\n";
                    }
                }
                else
                {
                    std::cin.clear();
                    std::cin >> temp;
                    std::cout << "\nError: You have entered a character or a string.\n\n";
                    std::cout << "Please enter a positive integer.\n";
                }
            }

            if (mylist -> findRecord(accountNumber) == 0)
            {
                std::cout << "\nYou have found a customer's record.\n";
            }
            else
            {
                std::cout << "\nA record has not been found.\n";
            }

            std::cin.getline(temp, 300);
        }
        else if (strcmp(menuOption, "d") == 0 || strcmp(menuOption, "de") == 0)
        {
            std::cout << "\nThe 'delete' menu option has been chosen.\n";
            std::cout << "\nPlease enter the customer's account number.\n";

            isAccountNumberValid = 0;
            while (isAccountNumberValid == 0)
            {
                if (std::cin >> accountNumber)
                {
                    if (accountNumber > 0)
                    {
                        isAccountNumberValid = 1;
                    }
                    else
                    {
                        std::cout << "\nError: You have entered a number ";
                        std::cout << "less than or equal to 0.\n\n";
                        std::cout << "Please enter a positive integer.\n";
                    }
                }
                else
                {
                    std::cin.clear();
                    std::cin >> temp;
                    std::cout << "\nError: You have entered a character or a string.\n\n";
                    std::cout << "Please enter a positive integer.\n";
                }
            }

            if (mylist -> deleteRecord(accountNumber) == 0)
            {
                std::cout << "\nYou have deleted a customer's record.\n";
            }
            else
            {
                std::cout << "\nA record has not been deleted.\n";
            }

            std::cin.getline(temp, 300);
        }
        else if (strcmp(menuOption, "del") == 0 || strcmp(menuOption, "dele") == 0)
        {
            std::cout << "\nThe 'delete' menu option has been chosen.\n";
            std::cout << "\nPlease enter the customer's account number.\n";

            isAccountNumberValid = 0;
            while (isAccountNumberValid == 0)
            {
                if (std::cin >> accountNumber)
                {
                    if (accountNumber > 0)
                    {
                        isAccountNumberValid = 1;
                    }
                    else
                    {
                        std::cout << "\nError: You have entered a number ";
                        std::cout << "less than or equal to 0.\n\n";
                        std::cout << "Please enter a positive integer.\n";
                    }
                }
                else
                {
                    std::cin.clear();
                    std::cin >> temp;
                    std::cout << "\nError: You have entered a character or a string.\n\n";
                    std::cout << "Please enter a positive integer.\n";
                }
            }

            if (mylist -> deleteRecord(accountNumber) == 0)
            {
                std::cout << "\nYou have deleted a customer's record.\n";
            }
            else
            {
                std::cout << "\nA record has not been deleted.\n";
            }

            std::cin.getline(temp, 300);
        }
        else if (strcmp(menuOption, "delet") == 0 || strcmp(menuOption, "delete") == 0)
        {
            std::cout << "\nThe 'delete' menu option has been chosen.\n";
            std::cout << "\nPlease enter the customer's account number.\n";

            isAccountNumberValid = 0;
            while (isAccountNumberValid == 0)
            {
                if (std::cin >> accountNumber)
                {
                    if (accountNumber > 0)
                    {
                        isAccountNumberValid = 1;
                    }
                    else
                    {
                        std::cout << "\nError: You have entered a number ";
                        std::cout << "less than or equal to 0.\n\n";
                        std::cout << "Please enter a positive integer.\n";
                    }
                }
                else
                {
                    std::cin.clear();
                    std::cin >> temp;
                    std::cout << "\nError: You have entered a character or a string.\n\n";
                    std::cout << "Please enter a positive integer.\n";
                }
            }

            if (mylist -> deleteRecord(accountNumber) == 0)
            {
                std::cout << "\nYou have deleted a customer's record.\n";
            }
            else
            {
                std::cout << "\nA record has not been deleted.\n";
            }

            std::cin.getline(temp, 300);
        }
        else if (strcmp(menuOption, "q") == 0 || strcmp(menuOption, "qu") == 0)
        {
            std::cout << "\nThe 'quit' menu option has been chosen.\n";
            std::cout << "\nYou have quit the program.\n";

            delete mylist;

            stopProgram = 1;
        }
        else if (strcmp(menuOption, "qui") == 0 || strcmp(menuOption, "quit") == 0)
        {
            std::cout << "\nThe 'quit' menu option has been chosen.\n";
            std::cout << "\nYou have quit the program.\n";

            delete mylist;

            stopProgram = 1;
        }
        else
        {
            std::cout << "\nError: You have entered an invalid menu option name.\n\n";
            std::cout << "Please enter a valid menu option.\n\n";
        }
    }

    return 0;
}

/*****************************************************************
//
//  Function name: getaddress
//
//  DESCRIPTION:   A getaddress function
//                 This function obtains the customer's
//                 address information.
//
//  Parameters:    addressArray (char []) : the array of the
//                                          customer's address
//                 addressSize (int) : the size of the addressArray
//
//  Return values:  There are no return values.
//
****************************************************************/

void getaddress(char addressArray[], int addressSize)
{
    int current;
    char nextCharacter;

    current = 0;

    while (current < addressSize - 1)
    {
        if (addressArray[current] != '\0')
        {
            addressArray[current] = '\0';
        }

        nextCharacter = std::cin.get();

        if (nextCharacter == '?')
        {
            current = addressSize;
        }
        else
        {
            addressArray[current] = nextCharacter;
            current++;
        }
    }

    addressArray[current] = '\0';
}
