/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 22, 2023
//
//  FILE:        llist.cpp
//
//  DESCRIPTION:
//   This file contains the database functions
//   for Project 2 - the bank database application in C++
//
****************************************************************/

#include <cstring>
#include <iostream>
#include <fstream>
using namespace std;
#include "llist.h"

/*****************************************************************
//
//  Function name: llist
//
//  DESCRIPTION:   A llist constructor
//                 This function is a constructor for llist with
//                 no parameter.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

llist::llist()
{
    this -> start = NULL;
    strcpy(this -> filename, "database.txt");

    if (readfile() == 0)
    {
        std::cout << "\nThe file 'database.txt' has been successfully read.\n";
    }
    else
    {
        std::cout << "\nThe file 'database.txt' has not been successfully read.\n";
    }
}

/*****************************************************************
//
//  Function name: llist
//
//  DESCRIPTION:   A llist constructor
//                 This function is a constructor for llist with
//                 a char [] parameter for the name of the file.
//
//  Parameters:    nameOfFile (char []) : the name of the file
//
//  Return values:  There are no return values.
//
****************************************************************/

llist::llist(char nameOfFile[])
{
    this -> start = NULL;
    strcpy(this -> filename, nameOfFile);

    if (readfile() == 0)
    {
        std::cout << "\nThe file 'database.txt' has been successfully read.\n";
    }
    else
    {
        std::cout << "\nThe file 'database.txt' has not been successfully read.\n";
    }
}

/*****************************************************************
//
//  Function name: llist
//
//  DESCRIPTION:   A llist copy constructor
//                 This function is a copy constructor for llist.
//                 This constructor creates a new llist object by
//                 copying the content from the provided
//                 original llist.
//
//  Parameters:    original (llist & original) : the original
//                                   llist object to be copied
//
//  Return values:  There are no return values.
//
****************************************************************/

llist::llist(llist & original)
{
    struct record * newRecord;
    struct record * originalRecord;

    originalRecord = original.start;

    this -> start = NULL;

    if (originalRecord != NULL)
    {
        this -> start = new record();
        newRecord = this -> start;
        newRecord -> accountno = originalRecord -> accountno;
        strcpy(newRecord -> name, originalRecord -> name);
        strcpy(newRecord -> address, originalRecord -> address);
        newRecord -> next = NULL;
        originalRecord = originalRecord -> next;

        while (originalRecord != NULL)
        {
            newRecord -> next = new record();
            newRecord = newRecord -> next;
            newRecord -> accountno = originalRecord -> accountno;
            strcpy(newRecord -> name, originalRecord -> name);
            strcpy(newRecord -> address, originalRecord -> address);
            newRecord -> next = NULL;
            originalRecord = originalRecord -> next;
        }
    }
}

/*****************************************************************
//
//  Function name: ~llist
//
//  DESCRIPTION:   A llist destructor
//                 This function deallocates the memory allocated
//                 on the heap.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

llist::~llist()
{
    if (writefile() == 0)
    {
        std::cout << "\nThe file 'database.txt' has been successfully written.\n";
    }
    else
    {
        std::cout << "\nThe file 'database.txt' has not been successfully written.\n";
    }

    cleanup();
}

/*****************************************************************
//
//  Function name: operator=
//
//  DESCRIPTION:   An overloaded operator= function
//                 This function assigns the values of a llist
//                 object to another llist object.
//
//  Parameters:    original (const llist &) : the original
//                                      llist object that the
//                                   content will be copied from
//
//  Return values:  *this (llist &) : the llist object after
//                                    copying the content
//                                    from the provided list
//
****************************************************************/

llist& llist::operator=(const llist & original)
{
    if (this != &original)
    {
        struct record * newRecord;
        struct record * originalRecord;

        originalRecord = original.start;

        this -> start = NULL;

        if (originalRecord != NULL)
        {
            this -> start = new record();
            newRecord = this -> start;
            newRecord -> accountno = originalRecord -> accountno;
            strcpy(newRecord -> name, originalRecord -> name);
            strcpy(newRecord -> address, originalRecord -> address);
            newRecord -> next = NULL;
            originalRecord = originalRecord -> next;

            while (originalRecord != NULL)
            {
                newRecord -> next = new record();
                newRecord = newRecord -> next;
                newRecord -> accountno = originalRecord -> accountno;
                strcpy(newRecord -> name, originalRecord -> name);
                strcpy(newRecord -> address, originalRecord -> address);
                newRecord -> next = NULL;
                originalRecord = originalRecord -> next;
            }
        }
    }

    return *this;
}

/*****************************************************************
//
//  Function name: operator<<
//
//  DESCRIPTION:   An overloaded operator<< function
//                 This function prints the values of a llist
//                 object.
//
//  Parameters:    output (ostream &) : an output stream that
//                                      prints the contents of
//                                      the entire database
//                 list (const llist &) : the llist that the
//                                        contains the content
//                                        to be printed
//
//  Return values:  output (ostream &) : an output stream that
//                                       prints the contents of
//                                       the entire database
//
****************************************************************/

ostream& operator<<(ostream & output, const llist & list)
{
    struct record * customerRecord;

    customerRecord = list.start;

    if (customerRecord != NULL)
    {
        while (customerRecord != NULL)
        {
            output << "\nAccount Number:\n" << customerRecord -> accountno;
            output << "\nName:\n" << customerRecord -> name;
            output << "\nMailing Address:\n" << customerRecord -> address << "\n";
            customerRecord = customerRecord -> next;
        }

        output << "\nAll records in the database have been printed.\n";
    }
    else
    {
        output << "\nThere are no customer records in the database.\n";
    }

    return output;
}

/*****************************************************************
//
//  Function name: addRecord
//
//  DESCRIPTION:   An addRecord function
//                 This function takes the customer's
//                 account number, name, and mailing address.
//                 Then, it adds the customer's record to the
//                 database.
//
//  Parameters:    uaccountno (int) : the customer's account number
//                 uname (char []) : the customer's name
//                 uaddress (char []) : the customer's mailing address
//
//  Return values:  0 : success, a record has been added to the database
//                 -1 : fail, a record has not been added to the database
//
****************************************************************/

int llist::addRecord(int uaccountno, char uname[], char uaddress[])
{
    int stop;
    int result;
    struct record * newRecord;
    struct record * addressOfPrevious;
    struct record * addressOfNext;
    struct record ** startAddress;

    stop = 0;
    result = -1;
    startAddress = &start;

    #ifdef DEBUG_MODE
    std::cout << "\nDebug Message:\n";
    std::cout << "The addRecord function has been called.\n";
    std::cout << "The function parameter names and values are listed below,\n";
    std::cout << "uaccountno: \n" << uaccountno << "\n";
    std::cout << "uname: \n" << uname << "\n";
    std::cout << "uaddress: \n" << uaddress << "\n";
    #endif

    if (*startAddress == NULL)
    {
        *startAddress = new record();
        (*startAddress) -> accountno = uaccountno;
        strcpy((*startAddress) -> name, uname);
        strcpy((*startAddress) -> address, uaddress);
        (*startAddress) -> next = NULL;

        result = 0;
    }
    else if (uaccountno == (*startAddress) -> accountno)
    {
        result = -1;
    }
    else if (uaccountno > (*startAddress) -> accountno)
    {
        newRecord = new record();
        newRecord -> accountno = uaccountno;
        strcpy(newRecord -> name, uname);
        strcpy(newRecord -> address, uaddress);
        newRecord -> next = *startAddress;
        *startAddress = newRecord;

        result = 0;
    }
    else
    {
        if ((*startAddress) -> next != NULL)
        {
            addressOfPrevious = *startAddress;
            addressOfNext = (*startAddress) -> next;
            while (stop == 0)
            {
                if (uaccountno == addressOfNext -> accountno)
                {
                    stop = 1;
                    result = -1;
                }
                else if (uaccountno < addressOfNext -> accountno)
                {
                    if (addressOfNext -> next == NULL)
                    {
                        newRecord = new record();
                        newRecord -> accountno = uaccountno;
                        strcpy(newRecord -> name, uname);
                        strcpy(newRecord -> address, uaddress);
                        newRecord -> next = NULL;
                        addressOfNext -> next = newRecord;

                        stop = 1;
                        result = 0;
                    }
                    else
                    {
                        addressOfPrevious = addressOfNext;
                        addressOfNext = addressOfNext -> next;
                    }
                }
                else
                {
                    newRecord = new record();
                    newRecord -> accountno = uaccountno;
                    strcpy(newRecord -> name, uname);
                    strcpy(newRecord -> address, uaddress);
                    newRecord -> next = addressOfNext;
                    addressOfPrevious -> next = newRecord;

                    stop = 1;
                    result = 0;
                }
            }
        }
        else
        {
            newRecord = new record();
            newRecord -> accountno = uaccountno;
            strcpy(newRecord -> name, uname);
            strcpy(newRecord -> address, uaddress);
            newRecord -> next = NULL;
            (*startAddress) -> next = newRecord;

            result = 0;
        }
    }

    return result;
}

/*****************************************************************
//
//  Function name: printAllRecords
//
//  DESCRIPTION:   A printAllRecords function
//                 This function prints all records in the
//                 database.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

void llist::printAllRecords()
{
    struct record * customerRecord;

    customerRecord = start;

    #ifdef DEBUG_MODE
    std::cout << "\nDebug Message:\n";
    std::cout << "The printAllRecords function has been called.\n";
    #endif

    if (customerRecord != NULL)
    {
        while (customerRecord != NULL)
        {
            std::cout << "\nAccount Number:\n" << customerRecord -> accountno;
            std::cout << "\nName:\n" << customerRecord -> name;
            std::cout << "\nMailing Address:\n" << customerRecord -> address << "\n";
            customerRecord = customerRecord -> next;
        }

        std::cout << "\nAll records in the database have been printed.\n";
    }
    else
    {
        std::cout << "\nThere are no customer records in the database.\n";
    }
}

/*****************************************************************
//
//  Function name: findRecord
//
//  DESCRIPTION:   A findRecord function
//                 This function takes the customer's account
//                 number.
//                 Then, it finds the customer's record(s)
//                 with the specified account number.
//
//  Parameters:    uaccountno (int) : the customer's account number
//
//  Return values:  0 : success, a record has been found in the database
//                 -1 : fail, a record has not been found in the database
//
****************************************************************/

int llist::findRecord(int uaccountno)
{
    int stop;
    int result;
    struct record * customerRecord;

    stop = 0;
    result = -1;
    customerRecord = start;

    #ifdef DEBUG_MODE
    std::cout << "\nDebug Message:\n";
    std::cout << "The findRecord function has been called.\n";
    std::cout << "The function parameter names and values are listed below,\n";
    std::cout << "uaccountno: \n"<< uaccountno << "\n";
    #endif

    if (customerRecord != NULL)
    {
        while (stop == 0)
        {
            if (customerRecord == NULL)
            {
                stop = 1;
            }
            else if (uaccountno == customerRecord -> accountno)
            {
                std::cout << "\nAccount Number:\n" << customerRecord -> accountno;
                std::cout << "\nName:\n" << customerRecord -> name;
                std::cout << "\nMailing Address:\n" << customerRecord -> address << "\n";

                stop = 1;
                result = 0;
            }
            else
            {
                customerRecord = customerRecord -> next;
            }
        }
    }

    return result;
}

/*****************************************************************
//
//  Function name: deleteRecord
//
//  DESCRIPTION:   A deleteRecord function
//                 This function takes the customer's account
//                 number.
//                 Then, it deletes the customer's existing record(s)
//                 from the database using the account number as a key.
//
//  Parameters:    uaccountno (int) : the customer's account number
//
//  Return values:  0 : success, a record has been deleted from the database
//                 -1 : fail, a record has not been deleted from the database
//
****************************************************************/

int llist::deleteRecord(int uaccountno)
{
    int stop;
    int result;
    struct record * temp;
    struct record * addressOfCurrent;
    struct record * addressOfNext;
    struct record ** startAddress;

    stop = 0;
    result = -1;
    startAddress = &start;

    #ifdef DEBUG_MODE
    std::cout << "\nDebug Message:\n";
    std::cout << "The deleteRecord function has been called.\n";
    std::cout << "The function parameter names and values are listed below,\n";
    std::cout << "uaccountno: \n" << uaccountno << "\n";
    #endif

    if (*startAddress != NULL)
    {
        if (uaccountno == (*startAddress) -> accountno)
        {
            if ((*startAddress) -> next == NULL)
            {
                delete *startAddress;
                *startAddress = NULL;

                result = 0;
            }
            else
            {
                temp = (*startAddress) -> next;
                delete *startAddress;
                *startAddress = temp;

                result = 0;
            }
        }
        else
        {
            addressOfCurrent = *startAddress;
            addressOfNext = (*startAddress) -> next;
            while (stop == 0)
            {
                if (addressOfNext != NULL && uaccountno == addressOfNext -> accountno)
                {
                    if (addressOfNext -> next != NULL)
                    {
                        temp = addressOfNext -> next;
                        delete addressOfNext;
                        addressOfCurrent -> next = temp;

                        stop = 1;
                        result = 0;
                    }
                    else
                    {
                        delete addressOfNext;
                        addressOfCurrent -> next = NULL;

                        stop = 1;
                        result = 0;
                    }
                }
                else
                {
                    if (addressOfNext == NULL)
                    {
                        stop = 1;
                    }
                    else if (addressOfNext -> next == NULL)
                    {
                        stop = 1;
                    }
                    else
                    {
                        addressOfCurrent = addressOfNext;
                        addressOfNext = addressOfNext -> next;
                    }
                }
            }
        }
    }
    return result;
}

/*****************************************************************
//
//  Function name: writefile
//
//  DESCRIPTION:   A writefile function
//                 This function will write the data stored in
//                 the database into a text file.
//
//  Parameters:    There are no parameters.
//
//  Return values:  0 : success, successfully opened file
//                 -1 : fail, unsuccessfully opened file
//
****************************************************************/

int llist::writefile()
{
    int successfulOpenFile;
    struct record * customerRecord;

    std::ofstream infile(filename, std::ofstream::out);
    successfulOpenFile = -1;
    customerRecord = start;

    #ifdef DEBUG_MODE
    std::cout << "\nDebug Message:\n";
    std::cout << "The writefile function has been called.\n";
    std::cout << "The function parameter names and values are listed below,\n";
    std::cout << "filename: \n" << filename << "\n";
    #endif

    if (infile.is_open())
    {
        successfulOpenFile = 0;

        while (customerRecord != NULL)
        {
            infile << customerRecord -> accountno << "?\n";
            infile << customerRecord -> name << "?\n";
            infile << customerRecord -> address << "?\n";
            customerRecord = customerRecord -> next;
        }

        infile.close();
    }

    return successfulOpenFile;
}

/*****************************************************************
//
//  Function name: readfile
//
//  DESCRIPTION:   A readfile function
//                 This function will read the data from a text
//                 file and store it in the database.
//
//  Parameters:    There are no parameters.
//
//  Return values:  0 : success, successfully opened file
//                 -1 : fail, unsuccessfully opened file
//
****************************************************************/

int llist::readfile()
{
    int successfulOpenFile;
    int raccountno;
    char rname[30];
    char raddress[50];
    struct record * addressOfCurrent;
    struct record * addressOfPrevious;
    struct record ** startAddress;

    int isFirstRecord;
    int currentPosition;
    char currentCharacter;

    std::ifstream infile(filename, std::ifstream::in);
    successfulOpenFile = -1;
    startAddress = &start;

    isFirstRecord = 1;

    #ifdef DEBUG_MODE
    std::cout << "\nDebug Message:\n";
    std::cout << "The readfile function has been called.\n";
    std::cout << "The function parameter names and values are listed below,\n";
    std::cout << "filename: \n" << filename << "\n";
    #endif

    if (infile.is_open())
    {
        successfulOpenFile = 0;

        while (infile >> raccountno)
        {
            if (isFirstRecord == 1)
            {
                *startAddress = new record();
                currentCharacter = infile.get();

                if (currentCharacter == '?')
                {
                    currentCharacter = infile.get();
                    currentCharacter = infile.get();
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        rname[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = infile.get();
                    }
                }

                if (currentCharacter == '?')
                {
                    currentCharacter = infile.get();
                    currentCharacter = infile.get();
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        raddress[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = infile.get();
                    }
                    currentCharacter = infile.get();
                }

                (*startAddress) -> accountno = raccountno;
                strcpy((*startAddress) -> name, rname);
                strcpy((*startAddress) -> address, raddress);
                (*startAddress) -> next = NULL;

                isFirstRecord = 0;

                addressOfPrevious = *startAddress;
            }
            else
            {
                addressOfCurrent = new record();
                addressOfPrevious -> next = addressOfCurrent;
                currentCharacter = infile.get();

                if (currentCharacter == '?')
                {
                    currentPosition = 0;
                    while (currentPosition < 29)
                    {
                        rname[currentPosition] = '\0';
                        currentPosition++;
                    }

                    currentCharacter = infile.get();
                    currentCharacter = infile.get();
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        rname[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = infile.get();
                    }
                }

                if (currentCharacter == '?')
                {
                    currentPosition = 0;
                    while (currentPosition < 49)
                    {
                        raddress[currentPosition] = '\0';
                        currentPosition++;
                    }

                    currentCharacter = infile.get();
                    currentCharacter = infile.get();
                    currentPosition = 0;
                    while (currentCharacter != '?')
                    {
                        raddress[currentPosition] = currentCharacter;
                        currentPosition++;
                        currentCharacter = infile.get();
                    }
                    currentCharacter = infile.get();
                }

                addressOfCurrent -> accountno = raccountno;
                strcpy(addressOfCurrent -> name, rname);
                strcpy(addressOfCurrent -> address, raddress);
                addressOfCurrent -> next = NULL;

                addressOfPrevious = addressOfCurrent;
            }
        }

        infile.close();
    }

    return successfulOpenFile;
}

/*****************************************************************
//
//  Function name: cleanup
//
//  DESCRIPTION:   A cleanup function
//                 This function will deallocate all the
//                 allocated spaces in the heap memory and
//                 assign NULL to start. It will clean up the
//                 heap memory by releasing all the allocated
//                 spaces in the heap memory, then assign NULL
//                 to start.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

void llist::cleanup()
{
    struct record * freeRecord;
    struct record ** startAddress;

    startAddress = &start;

    #ifdef DEBUG_MODE
    std::cout << "\nDebug Message:\n";
    std::cout << "The cleanup function has been called.\n";
    #endif

    while (*startAddress != NULL)
    {
        freeRecord = *startAddress;
        *startAddress = (*startAddress) -> next;
        delete freeRecord;
    }

    *startAddress = NULL;
}
