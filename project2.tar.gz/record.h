/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    Project 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 17, 2023
//
//  FILE:        record.h
//
//  DESCRIPTION:
//   This file contains the data structure of record
//   for Project 2 - the bank database application in C++
//
****************************************************************/

#ifndef RECORD_H
#define RECORD_H

struct record
{
    int accountno;
    char name[30];
    char address[50];
    struct record* next;
};

#endif
