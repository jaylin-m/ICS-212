/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        serperior.cpp
//
//  DESCRIPTION:
//   This file contains the member function definitions for the
//   child class Serperior
//   for Homework 9 - Inheritance
//
****************************************************************/

#include <iostream>
#include "serperior.h"

/*****************************************************************
//
//  Function name: Serperior
//
//  DESCRIPTION:   A Serperior constructor
//                 This function is a constructor for the child
//                 class Serperior.
//                 This function creates a Serperior object.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

Serperior::Serperior()
{
    type = "Grass";
    weight = 138.9;
    std::cout << "Serperior Constructor" << std::endl;
}

/*****************************************************************
//
//  Function name: ~Serperior
//
//  DESCRIPTION:   A Serperior destructor
//                 This function is a destructor for the child
//                 class Serperior.
//                 This function deletes a Serperior object.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

Serperior::~Serperior()
{
    std::cout << "Serperior Destructor" << std::endl;
}

/*****************************************************************
//
//  Function name: printData
//
//  DESCRIPTION:   A printData function
//                 This function prints the name of this child
//                 class, a string stored in 'type', and a value
//                 stored in 'weight'.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

void Serperior::printData()
{
    std::cout << "Serperior" << std::endl;
    std::cout << type << std::endl;
    std::cout << weight << std::endl;
}
