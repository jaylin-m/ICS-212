/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        greninja.h
//
//  DESCRIPTION:
//   This file contains the member function prototypes for the
//   child class Greninja
//   for Homework 9 - Inheritance
//
****************************************************************/

#ifndef GRENINJA_H
#define GRENINJA_H

#include "pokemon.h"

class Greninja : public Pokemon
{
    public:
    Greninja();
    virtual ~Greninja();
    void printData();
};

#endif
