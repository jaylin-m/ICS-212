/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        serperior.h
//
//  DESCRIPTION:
//   This file contains the member function prototypes for the
//   child class Serperior
//   for Homework 9 - Inheritance
//
****************************************************************/

#ifndef SERPERIOR_H
#define SERPERIOR_H

#include "pokemon.h"

class Serperior : public Pokemon
{
    public:
    Serperior();
    virtual ~Serperior();
    void printData();
};

#endif
