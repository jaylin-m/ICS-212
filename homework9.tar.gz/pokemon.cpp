/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        pokemon.cpp
//
//  DESCRIPTION:
//   This file contains the member function definitions for the
//   abstract parent class Pokemon
//   for Homework 9 - Inheritance
//
****************************************************************/

#include <iostream>
#include "pokemon.h"

/*****************************************************************
//
//  Function name: Pokemon
//
//  DESCRIPTION:   A Pokemon constructor
//                 This function is a constructor for the
//                 abstract parent class Pokemon.
//                 This function creates a Pokemon object.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

Pokemon::Pokemon()
{
    std::cout << "Pokemon Constructor" << std::endl;
}

/*****************************************************************
//
//  Function name: ~Pokemon
//
//  DESCRIPTION:   A Pokemon destructor
//                 This function is a destructor for the
//                 abstract parent class Pokemon.
//                 This function deletes a Pokemon object.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

Pokemon::~Pokemon()
{
    std::cout << "Pokemon Destructor" << std::endl;
}
