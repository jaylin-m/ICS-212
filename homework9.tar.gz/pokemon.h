/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        pokemon.h
//
//  DESCRIPTION:
//   This file contains the member variables and member function
//   prototypes for the abstract parent class Pokemon
//   for Homework 9 - Inheritance
//
****************************************************************/

#ifndef POKEMON_H
#define POKEMON_H

#include <string>

class Pokemon
{
    protected:
    std::string type;
    float weight;

    public:
    Pokemon();
    virtual ~Pokemon();
    virtual void printData() = 0;
};

#endif
