/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        greninja.cpp
//
//  DESCRIPTION:
//   This file contains the member function definitions for the
//   child class Greninja
//   for Homework 9 - Inheritance
//
****************************************************************/

#include <iostream>
#include "greninja.h"

/*****************************************************************
//
//  Function name: Greninja
//
//  DESCRIPTION:   A Greninja constructor
//                 This function is a constructor for the child
//                 class Greninja.
//                 This function creates a Greninja object.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

Greninja::Greninja()
{
    type = "Water, Dark";
    weight = 88.2;
    std::cout << "Greninja Constructor" << std::endl;
}

/*****************************************************************
//
//  Function name: ~Greninja
//
//  DESCRIPTION:   A Greninja destructor
//                 This function is a destructor for the child
//                 class Greninja.
//                 This function deletes a Greninja object.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

Greninja::~Greninja()
{
    std::cout << "Greninja Destructor" << std::endl;
}

/*****************************************************************
//
//  Function name: printData
//
//  DESCRIPTION:   A printData function
//                 This function prints the name of this child
//                 class, a string stored in 'type', and a value
//                 stored in 'weight'.
//
//  Parameters:    There are no parameters.
//
//  Return values:  There are no return values.
//
****************************************************************/

void Greninja:: printData()
{
    std::cout << "Greninja" << std::endl;
    std::cout << type << std::endl;
    std::cout << weight << std::endl;
}
