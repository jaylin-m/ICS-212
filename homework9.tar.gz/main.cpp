/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        main.cpp
//
//  DESCRIPTION:
//   This file contains the main function and the polymorphic
//   function prototype and definition of checkPokedex.
//   for Homework 9 - Inheritance
//
****************************************************************/

#include <string>
#include <iostream>
#include <vector>
#include <map>
#include "reshiram.h"
#include "serperior.h"
#include "greninja.h"

void checkPokedex(Pokemon *);

/*****************************************************************
//
//  Function name: main
//
//  DESCRIPTION:   A main function
//                 This function creates instances of all the
//                 child classes in the heap memory, and stores
//                 their addresses in pointers of Pokemon*.
//                 Then, it creates a vector container which
//                 stores three nicknames.
//                 Then, it creates a map container which
//                 stores a Pokemon pointer by its corresponding
//                 nickname as a key.
//                 Then, by using each element of the vector
//                 container, it accesses the corresponding
//                 item stored in the map container. It prints
//                 which key is being used, which item is being
//                 accessed, and the accessed Pokemon information.
//                 Then, it calls the checkPokedex function with
//                 the pointer, which prints all the three
//                 pokemon in the terminal.
//                 Lastly, it will clean up the heap memory,
//                 calling the child class destructors that
//                 delete the objects.
//
//  Parameters:    argc (int) : the number of elements in argv
//                 argv (char*[]) : an array of arguments passed
//                                  to the program
//
//  Return values:  0 : success
//
****************************************************************/

int main(int argc, char* argv[])
{
    Pokemon * pokemonReshiram;
    Pokemon * pokemonSerperior;
    Pokemon * pokemonGreninja;

    std::cout << "\nThe Pokemon objects are created," << "\n" << std::endl;

    pokemonReshiram = new Reshiram();
    pokemonSerperior = new Serperior();
    pokemonGreninja = new Greninja();

    std::vector<std::string> nicknames;
    nicknames.push_back("Emberstorm");
    nicknames.push_back("SuperiorSnek");
    nicknames.push_back("NinjaFroggy");

    std::map<std::string, Pokemon*> pokemonPointers;
    pokemonPointers["Emberstorm"] = pokemonReshiram;
    pokemonPointers["SuperiorSnek"] = pokemonSerperior;
    pokemonPointers["NinjaFroggy"] = pokemonGreninja;

    std::cout << std::endl;

    for (std::vector<std::string>::iterator key = nicknames.begin(); key != nicknames.end(); ++key)
    {
        std::cout << "\nThe key that is being used,";
        std::cout << "\nThe nickname of the Pokemon: " << *key << std::endl;
        std::cout << "\nThe item that is being accessed,";
        std::cout << "\nThe address of the corresponding Pokemon object: ";
        std::cout << pokemonPointers[*key] << std::endl;
        std::cout << "\nThe information of the Pokemon that was accessed," << "\n" << std::endl;
        checkPokedex(pokemonPointers[*key]);
        std::cout << std::endl;
    }

    std::cout << "\nThe Pokemon objects are deleted," << "\n" << std::endl;

    delete pokemonReshiram;
    delete pokemonSerperior;
    delete pokemonGreninja;

    return 0;
}

/*****************************************************************
//
//  Function name: checkPokedex
//
//  DESCRIPTION:   A checkPokedex function
//                 This function will receive a Pokemon pointer
//                 that points to a child object of the
//                 abstract parent class Pokemon.
//                 Then, the function will call the printData
//                 function of the child object's class.
//
//  Parameters:    pokemon (Pokemon *) : a pointer that points
//                                       to the address of the
//                                       Pokemon object
//
//  Return values:  There are no return values.
//
****************************************************************/

void checkPokedex(Pokemon * pokemon)
{
    pokemon -> printData();
}
