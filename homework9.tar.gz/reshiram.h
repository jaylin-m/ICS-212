/*****************************************************************
//
//  NAME:        Jaylin Morimoto
//
//  HOMEWORK:    9
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        December 1, 2023
//
//  FILE:        reshiram.h
//
//  DESCRIPTION:
//   This file contains the member function prototypes for the
//   child class Reshiram
//   for Homework 9 - Inheritance
//
****************************************************************/

#ifndef RESHIRAM_H
#define RESHIRAM_H

#include "pokemon.h"

class Reshiram : public Pokemon
{
    public:
    Reshiram();
    virtual ~Reshiram();
    void printData();
};

#endif
